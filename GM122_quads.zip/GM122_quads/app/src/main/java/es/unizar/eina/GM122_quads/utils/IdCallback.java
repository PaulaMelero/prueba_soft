package es.unizar.eina.GM122_quads.utils;

public interface IdCallback {
    void onInserted(long id);
}

